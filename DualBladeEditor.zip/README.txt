================================================================================
  DUAL BLADE EDITOR 0.9
  An expanded editor for Lufia II: Rise of the Sinistrals (SNES)

  by Percival, built on the Lufia II Editor by zanto
================================================================================


--------------------------------------------------------------------------------
WHAT THIS IS
--------------------------------------------------------------------------------

zanto's Lufia II Editor let you change enemies, spells and enemy skill names.
This is that editor with a lot more added: equipment, items, IP moves, shops,
characters and their growth, the starting party and EXP curve, capsule monsters
and their AI and feeding, the Ancient Cave, random encounters, in-game item and
spell descriptions, and the story dialogue. It can also fix a number of bugs in
the original game, one tick box at a time.

It is one program. zanto's three original tabs have been folded into the new
ones, so there is nothing to run side by side.

This is version 0.9 on purpose. Most of it has been used on a real mod in
progress, but no one person can test every feature to its limits. See
"HOW WELL TESTED IS THIS" below before you trust it with a long project.


--------------------------------------------------------------------------------
BEFORE YOU START
--------------------------------------------------------------------------------

1. Keep a copy of your ROM somewhere safe. Save writes straight into the ROM
   you opened. (The editor now keeps its own backups too - see BACKUPS - but a
   copy of your own costs nothing.)

2. Set a clean ROM: File > Set clean ROM to compare against...
   Pick an unmodified Lufia II ROM. This is worth doing before anything else.
   With it the editor can:
     - show every field that differs from the original in blue
     - put any field back with right-click > Restore original
     - list all your changes in plain words (File > Show changes report)
     - make a patch other people can apply (File > Create patch)
   It is remembered between sessions.

3. Headered or unheadered ROMs both work. The editor notices which you have.


--------------------------------------------------------------------------------
WHAT YOU CAN EDIT
--------------------------------------------------------------------------------

CHARACTERS
  Base stats and growth for all seven characters, with level 50 and level 99
  results and a level 1-99 chart. Growth can be edited either as one percentage
  per stat (scaling the original curve) or band by band for full control.
  Also the Ancient Cave starting bonus: in the cave everyone starts at level 1
  with no equipment and a permanent bonus for that run.

PARTY & EXP
  The new-game setup: who starts in the party, at what level, with what
  equipment, spells and inventory. Warnings appear if someone starts with
  something they can't equip.
  The EXP curve: the game has no experience table, it computes one, and this
  edits the numbers behind that with a live table of the result.

EQUIPMENT
  Name, price, who can equip it, stat bonuses and IP move. Status effects it
  causes or blocks. Elements: a weapon's attack element, armour that halves,
  blocks or reflects an element, and the guard effects that IP moves switch on.
  Also whether the item can turn up in Ancient Cave red chests.

ITEMS
  Name, price and what each consumable does.

SHOPS
  Every shop's stock: items, weapons, armour, spells and casino prizes. Shops
  share one block of space, so a shop can be given more stock by taking some
  from another. Shop numbers are labelled with their town.

CHESTS
  What every treasure chest holds: 177 chests on 81 maps. Pick a map, pick a
  chest, choose any item. "Find item" shows only the maps whose chests hold
  something matching what you type, so you can see where an item can be found.
  Maps can be named here as on the Encounters tab (shared MapNames.txt).
  Chests can't be added or removed - see KNOWN LIMITS. The Ancient Cave's
  chests are random and are on the Cave Loot tab.

CAVE LOOT
  The Ancient Cave's loot tables, including all 41 blue chest items, the potion
  and common tables, the Iris treasures, Providence, and the price rule that
  limits what can appear on each floor. There is also a one-click fix for the
  game's floor 10+ bug (see GAME BUGS below).

ENEMY OVERVIEW
  All 224 enemies in one sortable table: name, level, HP, MP, ATP, DFP, AGL,
  INT, GUT, MGR, EXP, gold, sprite, pattern, item drop and drop chance. Type in
  a cell to edit it. Read-only columns show EXP per HP (handy for spotting
  grinding targets), the real drop rate, the enemy's weaknesses and resistances,
  and the element of its normal attack.
  Find filters by name, element or drop. "AI" opens the enemy on the Enemy AI
  tab; "Where" shows everywhere it appears.
  AGL, INT, GUT and MGR are shown as the game uses them in battle (the ROM
  stores half and the game doubles it, so odd numbers round down to even).

ENEMY AI
  Every value inside an enemy's battle script, listed in the order the AI runs
  them and labelled in plain words: damage, healing, chances, conditions, status
  effects, spells cast, which skill is used. Each enemy has its own copy of its
  attacks, so changing one enemy's Voltage bolt doesn't change another's.
  Also here: the enemy's elemental weaknesses, resistances and immunities, and
  the enemy skill names (these are packed back to back, so each name can only
  use the letters it already has).

ENCOUNTERS
  Monster groups (192): the building block of every random fight. Up to 8
  enemies per group, with a plain-language explanation of how the game turns a
  group into a fight, and a "used by" line showing every place it appears.
  World map zones (16): which groups appear where, with weights shown as live
  percentages, a summary of the typical enemy level and EXP, and a picture of
  the world's encounter zones decoded from the game itself. Click the map to
  jump to a zone.
  Sea encounters, dungeon and town maps (which group each visible monster
  uses), Ancient Cave floors, a "find an enemy" lookup, and the world map
  encounter rate with a live preview of the average steps between fights.
  Boss and scripted battles (39): the exact enemies and their positions on the
  battle screen, including the Sinistrals, Camu, Idura, Pierre and Daniele.

SPELL EFFECTS
  Spell name, MP cost, gold cost, everything the spell's battle script does,
  and which characters can learn it (as checkboxes and as a grid covering all
  40 spells at once). Magic shops sell to anyone, but only the ticked
  characters can actually take the spell.

IP MOVES
  Name, IP cost, and everything the move does, with a note when several items
  share one effect. Guard and mirror IP moves list the equipment they switch on.

CAPSULE MONSTERS
  Stats and growth for all seven capsule monsters and their forms.

CAPSULE AI
  What each capsule monster does in battle, which skills it starts with and
  which it can learn as it levels, and the chance of learning one. Slots that
  can never do anything are locked so they can't be set by mistake.

CAPSULE FEEDING
  What each capsule wants to be fed, how much each food is worth, and the price
  brackets. Requests that can never be accepted are flagged, with one-click
  removal. Items with duplicate names are flagged too, since the game often
  asks for a different one than the one you'd guess.

DESCRIPTIONS
  The in-game help text for every item, spell and IP move (730 entries). Shows
  the text as the game's box will, with line-width warnings, and compresses
  what you type using the game's own word list. A word finder shows which words
  are cheap to use, and colour shading shows which parts of your text are
  costing space.

DIALOGUE
  About 4,900 lines of story dialogue, searchable and editable. Control codes
  appear as readable tags ([Hero] for the hero's name, [pause 2], and so on).
  Each line keeps exactly its original size in the ROM, so this is for fixing
  typos, tightening clumsy translation and rewording - not for writing longer
  speeches. See KNOWN LIMITS.

GAME FIXES
  Fixes for bugs in the original game, each with its own tick box: ticking
  applies it, unticking puts the original back. They come from Relnqshd's
  Lufia II Fixxxer Deluxe and his Artea name patch (see GAME BUGS YOU CAN FIX
  and CREDITS). A fix whose bytes you have changed some other way is shown
  but left alone.

--------------------------------------------------------------------------------
FILE MENU TOOLS
--------------------------------------------------------------------------------

Set clean ROM to compare against... / Stop comparing
  See BEFORE YOU START.

Repair enemy skill names from clean ROM
  Fixes ROMs damaged by the name bug in the original editor (see BUGS FIXED).

Create patch (BPS / IPS)...
  Makes a patch that turns the clean ROM into your edited ROM, including
  unsaved edits. BPS is recommended: it stores checksums of both ROMs, so
  patchers warn people who apply it to the wrong file.

Show changes report...
  Every difference from the clean ROM in plain words, grouped by area, for
  example "Dekar STR growth, levels 16-24: 32 -> 48" or "Shop 01 Elcid items:
  added Potion". Anything the editor can't name is listed at the end as raw
  file offsets, so nothing is hidden. Can be saved as a text file - useful as
  the basis of your own mod's changelog.

Check ROM for problems...
  Looks for likely mistakes: equipment nobody can equip, starting gear a
  character can't use, shop items priced at 0, spells nobody can learn, IP
  moves no item carries, enemies with drops that can never happen, feeding
  requests that can never be accepted, empty blue chest entries, and more.
  Problems that already exist in the original game are listed separately, so
  your own mistakes stand out. Nothing is changed automatically.

Restore from backup...
  See BACKUPS.

Expand ROM / Move descriptions back
  See ROM EXPANSION.


--------------------------------------------------------------------------------
BACKUPS
--------------------------------------------------------------------------------

Saving overwrites your ROM in place, so before every save the editor copies the
ROM as it currently is on disk into a "Lufia2Editor backups" folder next to it,
named with the date and time. The newest 10 are kept.

File > Restore from backup... lists them newest first and puts one back. It
backs up the current state first, so a restore can itself be undone.

Expanding or shrinking the ROM makes a backup too, tagged "(before expanding)".

If you close the editor, open another ROM or reload with changes that aren't
saved, it asks whether to save them first (Save / Don't save / Cancel).


--------------------------------------------------------------------------------
ROM EXPANSION
--------------------------------------------------------------------------------

The description text is nearly full in the original game: there is only about
100 bytes of slack across all 730 entries. If you want to rewrite descriptions
properly, File > Expand ROM adds empty space to the end of the ROM and moves
the descriptions there, giving them about 31 KB instead of 11 KB.

You can choose 3 MB (+512 KB) or 4 MB, which is the most a cartridge of this
type can hold. The game's header already declares 4 MB, so nothing else needs
changing. The unused part stays free for future features.

Patches made from an expanded ROM still apply to a normal, unmodified ROM, and
expanded ROMs run in snes9x, bsnes/higan, Mesen and on flash carts.

It can be undone (File > Move descriptions back) as long as the descriptions
still fit the original space.

After expanding, check descriptions in game: item menu, equipment screen,
shops, and the spell and IP move menus.


--------------------------------------------------------------------------------
HOW WELL TESTED IS THIS
--------------------------------------------------------------------------------

Used on a real mod and checked in game:
  shops, Ancient Cave starting stats and loot, capsule feeding, capsule AI and
  skills, equipment elements, enemy stats and encounters, character growth.

Checked but less heavily:
  descriptions, IP moves, items, party and EXP, patches, the changes report.

Newest and least tested - please be careful and keep backups:
  the Dialogue tab, ROM expansion, the Game Fixes tab, and the merging of
  zanto's original three tabs into the new ones (0.9 changed how saving works).
  The game fixes come from a patch whose author never finished testing it, so
  try each one in game before relying on it.

If you hit something wrong, the changes report and Check ROM are the fastest
way to see what the editor thinks it did.


--------------------------------------------------------------------------------
KNOWN LIMITS
--------------------------------------------------------------------------------

Most of the game's data is packed with no spare room, so the editor edits in
place wherever it has to. In practice:

  - Dialogue lines keep their exact size. You can reword freely and shorten
    at will, but a longer line only fits if it happens to compress better.
    Making dialogue genuinely longer would mean rebuilding the game's event
    scripts, which this editor does not do.

  - Equipment and enemies can only change effects they already have. A sword
    with no element can't be given one, and an enemy with no item drop can't
    be given a drop.

  - Treasure chests: any chest can hold any item, but chests can't be added or
    removed. The game's chest table has no spare room, and the chests
    themselves are placed in the compressed map data.

  - Monster groups, world zones and map monster lists have a fixed number of
    slots. Any slot can hold anything, but no slot can be added.

  - Names are capped at the space the game has for them: items 12 letters,
    capsules 12, monsters 13, spells 8. Enemy skill and IP move names can only
    use the letters they already have.

  - Dungeon monsters keep their map sprite whatever you set them to fight as.
    In the Ancient Cave the sprite is editable per group.

  - The game has no names for its 248 maps. You can name them yourself as you
    identify them; names are kept in MapNames.txt next to the editor, so they
    can be shared.

  - A small number of dialogue lines are deliberately left out of the list
    because they could not be identified as text with full confidence. The
    editor would rather skip a line than offer you script bytes to edit.

  - ROMs with Lufia II Fixxxer Deluxe already applied can be opened, but
    Enemy Overview, Enemy AI and Encounters are switched off: that patch moves
    the enemy data and enemy skill names somewhere this editor doesn't read.
    Start from a clean ROM and use the Game Fixes tab instead.


--------------------------------------------------------------------------------
BUGS IN THE ORIGINAL EDITOR THAT ARE FIXED
--------------------------------------------------------------------------------

Enemy skill names
  The original loader started two names late and had its offsets one slot off,
  so the box showed - and on switching saved into - the previous name, padded
  with spaces. That could run two names together in game. Names are now read
  through the game's own table. File > Repair enemy skill names from clean ROM
  fixes ROMs already damaged by this.

Item drop chance
  The original showed half the stored number and wrote it back rounded down to
  an even number. Every save quietly shaved a point off odd drop chances. The
  exact value is now kept, and labelled the way the game actually uses it.

Capsule monster names
  An earlier version of the new tabs saved these as 13 characters, overwriting
  the byte that ends the name, which makes the game reset when the capsule menu
  opens. Names are now 12 characters and the end markers are repaired
  automatically when a ROM is opened.

Enemy skill name not saved
  Save stored everything except the skill name box, so a name typed just before
  saving was lost unless you clicked elsewhere first.


--------------------------------------------------------------------------------
GAME BUGS YOU CAN FIX
--------------------------------------------------------------------------------

Ancient Cave floor 10+ equipment
  From around floor 9 the game stops putting anything but weapons and body
  armour in red chests, because of an arithmetic bug. The Cave Loot tab has a
  tick box that fixes it, and unticking puts the original code back.

Capsule monster feeding requests
  The game checks whether food is expensive enough before it checks whether it
  is the item the capsule asked for, so a requested item that is cheaper than
  its own price bracket is always refused as "Disgusting". 37 of the 76
  requests in the original game can never be accepted. The Capsule Feeding tab
  flags them and can remove them in one click.

Look-alike items
  Several items share a name (there are four different "Deadly sword"s, for
  example). A capsule asking for one of them may well mean a different one than
  the shop sells. The feeding tab marks these and can swap to the other version.

On the Game Fixes tab (from Lufia II Fixxxer Deluxe and the Artea patch)
  - Equip menu: switching characters could leave the end of the previous item
    name showing ("Knifeuip").
  - Settings menu: pressing Left on the last option ran random code (the
    "Level 0" / music menu bug).
  - Statue: using it from the main menu froze or reset the game. It is now a
    battle-only item.
  - Sea ring: added Anti-sea to attacks, which no enemy reacts to. It now adds
    Fire, as in Fixxxer.
  - Lucky blade: the two items of that name had different equip lists.
  - Mirror: Archfiend, Sphinx, Demise, Leech, Nosferato and Sly Fox only cast
    it when they already had it.
  - Bolt Fish: could lock up the game once out of MP.
  - Dark Warrior: wrong colour palette.
  - Gades in Shuman Tower and the Fortress of Doom: the strongest version
    instead of the weaker one. A balance change rather than a bug fix.
  - Artea: the menus called him "Arty" (and his bow "Arty's bow").

  Not included: Fixxxer's fixes that need longer enemy scripts (Nosferato's
  Contact, Copper Dragon's and Ninja's resistances, Erim's spells), and its
  map, graphics and text changes.


--------------------------------------------------------------------------------
CREDITS
--------------------------------------------------------------------------------

Original Lufia II Editor by zanto
  https://www.romhacking.net/utilities/1066/
  The enemy, spell and enemy skill editing, the ROM loading and the offset
  files this editor still uses are all his work. None of the rest would exist
  without it.

Everything added in this version by Percival, working with Claude, an AI
assistant made by Anthropic. Claude wrote most of the new code and did the
disassembly and ROM research. Percival directed the project, decided what the
editor should do, tested everything in game, took the emulator measurements
that found the treasure chests, and reported what was wrong until it worked.

Game fixes from Relnqshd's Lufia II Fixxxer Deluxe (1.0 beta) and his Artea
name patch, and those who helped him
  https://www.romhacking.net/hacks/229/
  The editor applies his fixes one at a time rather than using his patch, but
  finding and fixing these bugs was his work. He never finished testing
  Fixxxer or wrote its credits; several people helped him, and they deserve
  the thanks too. He left no readme or contact address, so he couldn't be
  asked or thanked directly. If you know how to reach him, please pass on the
  thanks.

Lufia II: Rise of the Sinistrals is by Neverland and Taito. This editor is an
unofficial fan tool and is not connected with them in any way. It does not
include the game: you supply your own ROM.


--------------------------------------------------------------------------------
LICENSE
--------------------------------------------------------------------------------

zanto released the original Lufia II Editor with its source code, and his
readme says: "If you intend to improve this editor, feel free to do that. But,
please, credit me." This editor is such an improvement, released on the same
terms and with its source code.

You're welcome to improve it further in turn. Please credit zanto for the
original editor, Percival for this version, and Relnqshd (and those who helped
him) if you use the game fixes.


--------------------------------------------------------------------------------
ALSO IN THIS DOWNLOAD
--------------------------------------------------------------------------------

  CHANGELOG.txt        what changed in each version
  TECHNICAL-NOTES.txt  ROM offsets, data formats and the game code behind every
                       feature. Worth reading if you want to extend the editor
                       or hack the game directly.
  MapNames.txt         names for the game's maps (the ROM has none). Created as
                       you name maps on the Encounters or Chests tab.
  LufiaItemOffsets.txt, LufiaMonsterOffsets.txt, LufiaSpellOffsets.txt
                       zanto's offset lists. The editor still needs them: keep
                       them next to the exe and don't edit them.
  source               the C# source, and build.bat to compile it with the
                       .NET Framework 4 that comes with Windows.
  lua-tools            two BizHawk Lua scripts (BSNESv115+ core) used to find
                       the treasure chest table: one lists which memory
                       changes during an action, one logs the code that writes
                       an address. Handy for finding more of the game's data.
